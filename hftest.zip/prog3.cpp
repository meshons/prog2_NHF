#include <iostream>

char myid[]   = "Stork Gábor,1MI,IMSC3,L3p <storkgaborka98@gmail.com.hu> NO047V\n";
char mytask[] = "Feladat = 3 ISO 8859-2\n";

int main(){
    std::cout << myid << mytask;
    return 0;
}